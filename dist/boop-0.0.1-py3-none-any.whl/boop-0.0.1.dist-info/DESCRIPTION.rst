Use it or don't


